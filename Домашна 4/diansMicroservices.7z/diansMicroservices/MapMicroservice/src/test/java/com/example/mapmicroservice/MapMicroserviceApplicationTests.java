package com.example.mapmicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MapMicroserviceApplicationTests {

    @Test
    void contextLoads() {
    }

}
