package com.example.mapmicroservice.controllers;

import com.example.mapmicroservice.model.Restaurants;
import com.example.mapmicroservice.service.RestaurantService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/Map")
public class MapController {

    final RestaurantService restaurantService;

    public MapController( RestaurantService restaurantService) {
        this.restaurantService = restaurantService;

    }

    @GetMapping
    public List<Restaurants> getMapSkopje(Model model) {
        List<Restaurants> restaurantsSkopje = this.restaurantService.findAllSkopje();
        /*model.addAttribute("restaurantsSkopje", restaurantsSkopje);
        model.addAttribute("bodyContent", "MapSkopje.html");
        return "template";*/
        return restaurantsSkopje;
    }


}
