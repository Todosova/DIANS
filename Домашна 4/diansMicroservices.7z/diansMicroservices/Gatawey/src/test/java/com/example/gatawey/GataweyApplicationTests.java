package com.example.gatawey;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GataweyApplicationTests {

    @Test
    void contextLoads() {
    }

}
