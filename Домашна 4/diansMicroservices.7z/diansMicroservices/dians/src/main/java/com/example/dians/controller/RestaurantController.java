package com.example.dians.controller;
import com.example.dians.mod.Restaurants;
import com.example.dians.service.RestaurantService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/Restaurants")
public class RestaurantController {

    @Autowired
    final RestaurantService restaurantService;

    public RestaurantController(RestaurantService restaurantService) {
        this.restaurantService = restaurantService;
    }


    @GetMapping("/Skopje")
    public List<Restaurants>getAttractionsSkopje(Model model){
        List<Restaurants> attractionsSkopje=this.restaurantService.findAllSkopje();
       /* model.addAttribute("restaurantsSkopje", attractionsSkopje);
        model.addAttribute("bodyContent", "RestaurantsSkopje");
        return "template";*/
        return attractionsSkopje;
    }



    @PostMapping("/Skopje")
    public List<Restaurants> attractionsSearchSkopje(Model model,@RequestParam(value = "searchSkopje",required = false) String searchSkopje){
        List<Restaurants> foundSkopje= this.restaurantService.findByName(searchSkopje);
        /*model.addAttribute("foundSkopje", this.restaurantService.findByName(searchSkopje));
        model.addAttribute("bodyContent", "RestaurantsSkopje");
        return "template";*/
        return foundSkopje;
    }



}

